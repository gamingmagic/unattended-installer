#!/bin/sh
cd /home/Desktop/rAthena
./map-server
