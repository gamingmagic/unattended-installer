#!/bin/sh
cd /home/rathena/Desktop/rAthena
./login-server
