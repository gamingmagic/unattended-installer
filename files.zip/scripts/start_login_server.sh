#!/bin/sh
cd /home/Desktop/rAthena
./login-server
