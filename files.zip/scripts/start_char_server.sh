#!/bin/sh
cd /home/Desktop/rAthena
./char-server
